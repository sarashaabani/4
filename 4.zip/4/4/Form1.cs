﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;


namespace _4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string Family = textBox2.Text;
            string PhoneNumber = textBox3.Text;
            string All = Name + ',' + Family + ',' + PhoneNumber + '\n';
            var ns = File.Create("info.csv");
            ns.Close();
            File.WriteAllText("info.csv", All);
            textBox1.Text ="";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string Name = textBox1.Text;
            string Family = textBox2.Text;
            string PhoneNumber = textBox3.Text;
            string All = Name + ',' + Family + ',' + PhoneNumber + '\n';
            var ns = File.Create("info.csv");
            ns.Close();
            File.AppendAllText("info.csv", All);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }
    }
}
